﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CS422
{
    public class ThreadPoolSleepSorter : IDisposable
    {
        TextWriter tw;  //record the textwriter member variable
        BlockingCollection<MyTask> coll;  //record the collection of tasks 
        Thread[] threads;   // store threads
        int num_availthread;

        public ThreadPoolSleepSorter(TextWriter output, ushort threadCount) // constructor
        {
            tw = output;
            if (threadCount == 0)
            {
                coll = new BlockingCollection<MyTask>(64);
                threads = new Thread[64];
                for (int i = 0; i < 64; i++)
                {
                    threads[i] = new Thread(ThreadWorkFunc);
                    threads[i].Start();
                    while (!threads[i].IsAlive)     // make sure threads are alive
                    {
                    }
                }
            }
            else
            {
                coll = new BlockingCollection<MyTask>(threadCount);
                threads = new Thread[threadCount];
                for (int i = 0; i < threadCount; i++)
                {
                    threads[i] = new Thread(ThreadWorkFunc);
                    threads[i].Start();
                    while (!threads[i].IsAlive)
                    {
                    }
                }
            }
            num_availthread = threads.Length;   // num_availthread is used when we want to check whether we can really do tasks


        }

        public void Sort(byte[] values)
        {
            while ((coll.Count != 0) || (num_availthread != threads.Length))    // if previous tasks are not all finished, we need to wait
            {
            }
            
            for (int i = 0; i < values.Length; i++)     // add tasks
            {
                MyTask tmp = new MyTask();
                tmp.data = (int)values[i];
                coll.Add( tmp);
            }

            //Thread.Sleep(5000);
        }

        public void ThreadWorkFunc()
        {
            while (coll != null)
            { 
                MyTask tmp = coll.Take();   // take a task, and do writeline
                if(tmp != null)
                {
                    num_availthread--;
                    tmp.Go();
                    tw.WriteLine(tmp.data);
                    num_availthread++;
                }
                else
                {
                    break;
                }
            }
        }

        public void Dispose()   // stop the threads by sending null tasks
        {
            for ( int i = 0; i < threads.Length; i++)
            {
                MyTask tmp = null;
                coll.Add(tmp);
            }
            while(coll.Count != 0)
            {

            }
            coll = null;
        }
    }

    public class MyTask // MyTask class with function of sleep
    {
        public int data;

        public void Go()
        {
            Thread.Sleep( 800 * data);
        }
    }

}
