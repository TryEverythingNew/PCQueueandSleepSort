﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS422
{
    public class Node   // Node definition
    {
        public int data;    //  integer value data
        public Node next;

        public Node( int value)
        {
            data = value;
            next = null;
        }
    }

    public class PCQueue
    {
        // 3 member variables, dummy, Front, and Back
        Node dummy;
        Node F;
        Node B;

        // initialize dummy, and make B, F refer to dummy
        public PCQueue()
        {
            dummy = new Node(0);
            B = dummy;
            F = B;
        }

        
        // no lock thread-safe dequeue method
        public bool Dequeue(ref int out_value)
        {
            
            if (object.ReferenceEquals(B, dummy))   // if B == dummy, return false
            {
                return false;
            }
            else if (object.ReferenceEquals(F, dummy))
            {
                if (F.next == null) // if F.next is null and F == dummy, return false
                {
                    return false;
                }
                else    // if F.next not null and F == dummy, move F
                {
                    F = F.next;
                    return false;
                }
            }
            else 
            {
                if (F.next == null) // if F.next is null and F != dummy, set dummy to F
                {
                    out_value = F.data; // output value
                    dummy = F;
                    return true;
                }
                else    // if F.next is not null and F != dummy, move F and output
                {
                    out_value = F.data; // output value and move F to the next node
                    F = F.next;
                    return true;
                }
            }
        }


        // no lock thread-safe enqueue method
        public void Enqueue(int dataValue)
        {           
            B.next = new Node(dataValue);   // create new node
            B = B.next;
        }
    }
}
